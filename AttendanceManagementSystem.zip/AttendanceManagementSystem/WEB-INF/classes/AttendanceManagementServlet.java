import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@WebServlet(name = "AttendanceManagementServlet", urlPatterns = {"/attendance-management"})
public class AttendanceManagementServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:sqlite:C:/apache-tomcat-10.1.34/webapps/AttendanceManagementSystem/attendify.db";
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String lecturerId = (String) request.getSession().getAttribute("userId");
        String courseCode = request.getParameter("courseCode");


        if (lecturerId == null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Please log in first");
            return;
        }

        try {
            Class.forName("org.sqlite.JDBC");
            Map<String, Object> data = getCurrentAttendanceData(lecturerId, courseCode);
            
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(gson.toJson(data));

        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String lecturerId = (String) request.getSession().getAttribute("userId");
        String courseCode = request.getParameter("courseCode");

        if (lecturerId == null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Please log in first");
            return;
        }

        try {
            Class.forName("org.sqlite.JDBC");
            
            Map<String, Object> result = new HashMap<>();
            
            switch (action) {
                case "reset":
                    resetWeeklyAttendance(lecturerId, courseCode);
                    result.put("message", "Successfully reset attendance for the current week");
                    result.put("success", true);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
                    return;
            }
            
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(gson.toJson(result));
            
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Error: " + e.getMessage());
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(gson.toJson(error));
        }
    }

    private Map<String, Object> getCurrentAttendanceData(String lecturerId, String courseCode) throws SQLException, ClassNotFoundException {
        Map<String, Object> data = new HashMap<>();
        List<Map<String, Object>> attendanceRecords = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            String query = 
                "SELECT a.*, s.full_name as student_name, c.course_name " +
                "FROM attendance a " +
                "JOIN students s ON a.student_id = s.student_id " +
                "JOIN courses c ON a.course_code = c.course_code " +
                "WHERE c.lecturer_id = ? " +
                "AND date(a.check_in_date) >= date('now', 'weekday 0', '-7 days') " +
                "AND date(a.check_in_date) <= date('now') ";

            if (courseCode != null && !courseCode.trim().isEmpty()) {
                query += "AND a.course_code = ? ";
            }

            query += "ORDER BY a.check_in_date DESC, a.check_in_time DESC";

            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, lecturerId);
                if (courseCode != null && !courseCode.trim().isEmpty()) {
                    pstmt.setString(2, courseCode);
                }

                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        Map<String, Object> record = new HashMap<>();
                        record.put("studentId", rs.getString("student_id"));
                        record.put("studentName", rs.getString("student_name"));
                        record.put("courseCode", rs.getString("course_code"));
                        record.put("courseName", rs.getString("course_name"));
                        record.put("checkInDate", rs.getString("check_in_date"));
                        record.put("checkInTime", rs.getString("check_in_time"));
                        record.put("latitude", rs.getDouble("latitude"));
                        record.put("longitude", rs.getDouble("longitude"));
                        record.put("voiceVerified", rs.getBoolean("voice_verified"));
                        attendanceRecords.add(record);
                    }
                }
            }
        }

        data.put("records", attendanceRecords);
        return data;
    }



    private void resetWeeklyAttendance(String lecturerId, String courseCode) throws SQLException, ClassNotFoundException {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {

            // Then delete the current week's attendance
            String deleteQuery = 
                "DELETE FROM attendance WHERE course_code IN " +
                "(SELECT course_code FROM courses WHERE lecturer_id = ?) " +
                "AND date(check_in_date) >= date('now', 'weekday 0', '-7 days') " +
                "AND date(check_in_date) <= date('now')";
            
            if (courseCode != null && !courseCode.trim().isEmpty()) {
                deleteQuery = 
                    "DELETE FROM attendance WHERE course_code = ? " +
                    "AND date(check_in_date) >= date('now', 'weekday 0', '-7 days') " +
                    "AND date(check_in_date) <= date('now')";
            }

            try (PreparedStatement pstmt = conn.prepareStatement(deleteQuery)) {
                if (courseCode != null && !courseCode.trim().isEmpty()) {
                    pstmt.setString(1, courseCode);
                } else {
                    pstmt.setString(1, lecturerId);
                }
                pstmt.executeUpdate();
            }
        }
    }


}
